function Restaurant() {
  return (
    <>
      <div
        className="modal fade"
        id="slideShow"
        tabIndex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg " style={{ height: "75vh " }}>
          <div className="modal-content">
            <div className="modal-body h-75">
              {/* <Carousel showThumbs={false} infiniteLoop={true}>
                {rDetails.thumb.map((value, index) => {
                  return (
                    <div key={index} className="w-100">
                      <img src={"/images/" + value} />
                    </div>
                  );
                })}
              </Carousel> */}
            </div>
          </div>
        </div>
      </div>
      <div
        className="modal fade"
        id="exampleModalToggle"
        aria-hidden="true"
        aria-labelledby="exampleModalToggleLabel"
        tabIndex="-1"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalToggleLabel">
                name
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body ">
              <div className="row p-2">
                <div className="col-8">
                  <p className="mb-1 h6">name</p>
                  <p className="mb-1">price</p>
                  <p className="small text-muted">description</p>
                </div>
                <div className="col-4 d-flex justify-content-end">
                  <div className="menu-food-item">
                    <img src="/images/" alt="" />

                    <button className="btn btn-primary btn-sm add">Add</button>

                    <div className="order-item-count section ">
                      <span className="hand">-</span>
                      <span>qty</span>
                      <span className="hand">+</span>
                    </div>
                  </div>
                </div>
                <hr className=" p-0 my-2" />
              </div>

              <div className="d-flex justify-content-between">
                <h3>Subtotal subTotal</h3>
                <button
                  className="btn btn-danger"
                  data-bs-target="#exampleModalToggle2"
                  data-bs-toggle="modal"
                >
                  Pay Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        className="modal fade"
        id="exampleModalToggle2"
        aria-hidden="true"
        aria-labelledby="exampleModalToggleLabel2"
        tabIndex="-1"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalToggleLabel2">
                name
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Full Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="exampleFormControlInput1"
                  placeholder="Enter full Name"
                  value="deepakkumar"
                />
              </div>
              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlInput1"
                  className="form-label"
                >
                  Email
                </label>
                <input
                  type="email"
                  className="form-control"
                  id="exampleFormControlInput1"
                  placeholder="name@example.com"
                  value="deepak@gmail.com"
                />
              </div>
              <div className="mb-3">
                <label
                  htmlFor="exampleFormControlTextarea1"
                  className="form-label"
                >
                  Address
                </label>
                <textarea
                  className="form-control"
                  id="exampleFormControlTextarea1"
                  rows="3"
                  value="Nashik"
                ></textarea>
              </div>
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-danger"
                data-bs-target="#exampleModalToggle"
                data-bs-toggle="modal"
              >
                Back
              </button>
              <button className="btn btn-success">PROCEED</button>
            </div>
          </div>
        </div>
      </div>

      <div className="row bg-danger justify-content-center">
        <div className="col-10 d-flex justify-content-between py-2">
          <p className="m-0 brand">e!</p>
          <div>
            <button className="btn text-white">Login</button>
            <button className="btn btn-outline-light">
              <i className="fa fa-search" aria-hidden="true"></i>Create a
              Account
            </button>
          </div>
        </div>
      </div>
      {/* <!-- section -->  */}
      <div className="row justify-content-center">
        <div className="col-10">
          <div className="row">
            <div className="col-12 mt-5">
              <div className="restaurant-main-image position-relative">
                <img src="/images/food-item.png" alt="" className="" />
                <button
                  className="btn btn-outline-light position-absolute btn-gallery"
                  data-bs-toggle="modal"
                  data-bs-target="#slideShow"
                >
                  Click To Get Image Gallery
                </button>
              </div>
            </div>
            <div className="col-12">
              <h3 className="mt-4">name</h3>
              <div className="d-flex justify-content-between">
                <ul className="list-unstyled d-flex gap-3">
                  <li>Overview</li>
                  <li>Contact</li>
                </ul>
                <a
                  className="btn btn-danger align-self-start"
                  data-bs-toggle="modal"
                  href="#exampleModalToggle"
                  role="button"
                >
                  Place Online Order
                </a>
              </div>
              <hr className="mt-0" />

              <div className="over-view">
                <p className="h5 mb-4">About this place</p>

                <p className="mb-0 fw-bold">Cuisine</p>
                <p></p>

                <p className="mb-0 fw-bold">Average Cost</p>
                <p>₹ for two people (approx.)</p>
              </div>

              <div className="over-view">
                <p className="mb-0 fw-bold">Phone Number</p>
                <p>contact_number</p>

                <p className="mb-0 fw-bold">Address</p>
                <p>rDetails</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Restaurant;
